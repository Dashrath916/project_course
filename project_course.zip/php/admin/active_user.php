<?php 
include 'config.php';
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$sql = "UPDATE `users` SET status=1 WHERE id=$id";
	$result=mysqli_query($db, $sql);
	if($result){
		echo "<script>alert('Updated Successfully.')</script>";
    	header("Refresh:0");
		header("Location: new_users.php?success=1");
	}else{
		echo "<script>alert('Try agian')</script>";
	}
}
 ?>