<?php include 'session.php'; ?>
<?php 
include 'config.php';
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$sql = "DELETE FROM notes WHERE id=$id";
	$result=mysqli_query($db, $sql);
	if($result){
		echo "<script>alert('Updated Successfully.')</script>";
    	header("Refresh:0");
		header("Location: new_notes.php?success=1");
	}else{
		echo "<script>alert('Try agian')</script>";
	}
}
 ?>