<?php include 'session.php'; ?>
<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<style>
body {
  margin: 0;
  font-family: "Lato", sans-serif;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}
 
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
</style>
</head>
<body>

<div class="sidebar">
  <a class="active" href="index.php">Home</a>
  <a href="users.php">All Users</a>
  <a href="notes.php">All Notes</a>
  <a href="new_users.php">New Users</a>
  <a href="new_notes.php">New Notes</a>
  <a href="logout.php">Logout</a>
</div>

<div class="content">
  <div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><?php echo mysqli_num_rows(mysqli_query($db, "SELECT * FROM users"));?></h5>
        <p class="card-text">All Users</p>
        <a href="users.php" class="btn btn-primary">VEIW</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><?php echo mysqli_num_rows(mysqli_query($db, "SELECT * FROM notes"));?></h5>
        <p class="card-text">All Notes</p>
        <a href="notes.php" class="btn btn-primary">VEIW</a>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><?php echo mysqli_num_rows(mysqli_query($db, "SELECT * FROM users WHERE status=0"));?></h5>
        <p class="card-text">New Users Request</p>
        <a href="new_users.php" class="btn btn-primary">VEIW</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><?php echo mysqli_num_rows(mysqli_query($db, "SELECT * FROM notes WHERE status=0"));?></h5>
        <p class="card-text">New Notes Request</p>
        <a href="new_notes.php" class="btn btn-primary">VEIW</a>
      </div>
    </div>
  </div>
</div>
</div>

</body>
</html>
