<?php include 'session.php'; ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
body {
  margin: 0;
  font-family: "Lato", sans-serif;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}
 
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 16px;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}
</style>
</head>
<body>

<div class="sidebar">
  <a class="active" href="index.php">Home</a>
  <a href="users.php">Users</a>
  <a href="notes.php">All Notes</a>
  <a href="new_users.php">New Users</a>
  <a href="new_notes.php">New Notes</a>
  <a href="logout.php">Logout</a>
</div>

<div class="content">
  <h2>New Users Requests</h2>

<?php 
if(isset($_REQUEST['success'])==1)
{
    echo "<div style='background: #c2eac2; width: 244px; padding: 20px; color: green; border-radius: 14px; text-align: center; margin-top: 18px;'>Updated Successfully</div>";
}
 ?>

<table>
  <tr>
    <th>Notes Name</th>
    <th>Semester</th>
    <th>Upload by</th>
    <!-- <th>Action</th> -->
    <th>Delete</th>
  </tr>
  <?php
include 'config.php';
$query = $db->query("SELECT * FROM notes WHERE status=1 ORDER BY id  DESC");
if($query->num_rows > 0){
    while($row = $query->fetch_assoc()){
?>
  <tr>
    <td><?php echo $row['file_name']?></td>
    <td><?php echo $row['sem']?></td>
    <td><?php echo $row['upby']?></td>
    <!-- <td><a href="active_notes.php?id=<?php echo $row['id']?>" class="btn btn-success" onclick="return confirm('Are you sure?')">Accapt</a></td> -->
    <td><a href="delete_notes.php?id=<?php echo $row['id']?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a></td>
  </tr>
  <?php }} ?>
</table>
</div>

</body>
</html>