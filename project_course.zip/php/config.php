<?php
// Database configuration
$dbHost     = "127.0.0.1";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "project";

// Create database connection
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
// if($db==true){
//     echo "ok";
// }
// Check connection
// if ($db==true) {
//     echo "ok";
// }else{
//     echo "failed";
// }
?>