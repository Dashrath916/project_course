<?php include 'session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Semester 1</h2>
  <a href="index.php" class="btn btn-info btn-lg">Home</a>
  <center><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Add New</button></center>

    <img src="<?php echo $imageURL; ?>" alt="" />

  <table class="table">
    <thead>
      <tr>
        <th>Pdf</th>
        <th>Semester</th>
        <th>Uploaded By</th>
      </tr>
    </thead>
    <tbody>
    <?php
include 'config.php';
$query = $db->query("SELECT * FROM notes WHERE sem=3  AND status=1");
if($query->num_rows > 0){
    while($row = $query->fetch_assoc()){
        $imageURL = 'uploads/'.$row["file_name"];
?>
      <tr>
        <td><a href="<?php echo 'uploads/'.$row["file_name"];?>"><?php echo $row["file_name"];?></a></td>
        <td><?php echo $row["sem"];?></td>
        <td><?php echo $row["upby"];?></td>
      </tr>
      <?php }
}else{ ?>
    <p>No Data found...</p>
<?php } ?>
    </tbody>
  </table>
</div>

</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Upload New pdf File</h4>
        </div>
        <div class="modal-body">
        <form action="" enctype="multipart/form-data" method="post">
            <input type="file" name="file" class="form-control"><br><br>
            <center><input type="submit" name="submit" value="Upload" class="btn btn-success"></center>
        </form>
    </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

<?php
// Include the database configuration file
include 'config.php';
$statusMsg = '';

// File upload path
$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
    session_start();
    $name=$_SESSION['name'];
    $allowTypes = array('pdf');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
            // Insert image file name into database
            $insert = $db->query("INSERT into notes (file_name, sem, upby) VALUES ('".$fileName."', '3', '".$name."')");
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
            }else{
                $statusMsg = "File upload failed, please try again.";
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }else{
        $statusMsg = 'Sorry, only PDF files are allowed to upload.';
    }
}
// Display status message
echo $statusMsg;
?>
</body>
</html>
